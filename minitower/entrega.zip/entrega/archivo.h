#ifndef ARCHIVO_H
#define ARCHIVO_H

#include "mapa.h"
#include "nivel.h"

#define MAX_LINEA 256

int procesar_fila(char*, int, int, TipoCasilla**, Coordenada*, int);
        
#endif
