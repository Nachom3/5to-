# Compilación

```
$ make
```

Para regenerar todos los archivos objeto:
```
$ make clean && make
```

# Ejecución

```
$ ./tower_defense
```

# Profiling

```
$ valgrind --leak-check=full ./tower_defense
```